﻿Team 03 : Piyush Hemant Bhaise, Marie Clara Bofferding, Robert Eichner, Dominik Lindner
Requirements: 
* Python 3.7
* JupyterLab or Notebook

Instructions:
   * Download the Files
   * Open the “main.ipynb” file using jupyter notebook
   * Execute all cells
   * The dependency should be installed via the “requirements.txt” at the beginning (this can take a while)
The comments tell you which values can be changed. 
For the labeloracle input "y" (lowercase) for must link everything else is cannot link.


Working on Windows 10, Fedora 35, Manjaro